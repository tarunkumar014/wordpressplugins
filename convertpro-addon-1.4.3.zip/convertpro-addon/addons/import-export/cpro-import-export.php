<?php
/**
 * Convert Pro Addon Import/export loader file
 *
 * @package ConvertPro Addon
 * @author Brainstorm Force
 */

// Prohibit direct script loading.
defined( 'ABSPATH' ) || die( 'No direct script access allowed!' );

require_once 'classes/class-cpro-import-export.php';

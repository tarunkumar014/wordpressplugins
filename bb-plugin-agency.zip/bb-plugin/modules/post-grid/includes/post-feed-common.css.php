.fl-node-<?php echo $id; ?> .fl-post-feed-post {
	margin-bottom: <?php echo $settings->feed_post_spacing; ?>px;
}
.fl-node-<?php echo $id; ?> .fl-post-feed-post:last-child {
	margin-bottom: 0 !important;
}

<div class="fl-global-template-message">
	<div class="fl-global-template-message-label"><?php _e( 'Global', 'fl-builder' ); ?></div>
	<?php /* translators: %s: row or module */ ?>
	<div class="fl-global-template-message-content"><?php printf( _x( 'This is a global %s. Changes will appear everywhere it has been placed.', '%s stands for either row or module.', 'fl-builder' ), $type ); ?></div>
</div>

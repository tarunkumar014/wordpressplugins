<?php
/**
 * Fields.
 *
 * @package ConvertPro
 */

$text_attributes = array(
	'id'      => 'cp_box_shadow_par',
	'type'    => 'box_shadow',
	'scripts' => '',
	'styles'  => '',
);

echo wp_json_encode( $text_attributes );

<?php
/**
 * Advanced Search - Search Box
 *
 * @package Astra Addon
 */

?>
<div class="ast-search-menu-icon ast-inline-search">
	<?php astra_get_search_form(); ?>
</div>
